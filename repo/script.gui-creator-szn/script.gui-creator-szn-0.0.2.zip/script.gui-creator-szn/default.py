import xbmc
import xbmcgui
import xbmcaddon
import textviewer

Addon = xbmcaddon.Addon()
addon = Addon.getAddonInfo('id')
addonName = Addon.getAddonInfo('name')


# textviewer.window()

class Main:
    def __init__(self):
        self.status = 'failed'


class Background(xbmcgui.Window):
    def __init__(self):
        self.background = (xbmc.translatePath('special://home/addons/script.gui-creator/fanart.jpg'))
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, self.background, aspectRatio=1))


class Display(xbmcgui.Window):
    # background and four input dialog buttons
    previous_menu = 10
    back = 92

    def __init__(self):
        self.background = (xbmc.translatePath('special://home/addons/script.gui-creator/fanart.jpg'))
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, self.background, aspectRatio=1))
        self.strActionInfo = xbmcgui.ControlLabel(570, 300, 300, 300, '', 'font30', '0xFFFFFFFF')
        self.addControl(self.strActionInfo)
        self.strActionInfo.setLabel(addonName)
        self.button0 = xbmcgui.ControlButton(390, 380, 135, 30, " Notification")
        self.addControl(self.button0)
        self.button1 = xbmcgui.ControlButton(580, 380, 135, 30, "      Test 2")
        self.addControl(self.button1)
        self.button2 = xbmcgui.ControlButton(790, 380, 135, 30, "       Exit")
        self.addControl(self.button2)
        # self.button3 = xbmcgui.ControlButton(580, 430, 135, 30, "   Test 3)
        self.button3 = xbmcgui.ControlButton(580, 430, 135, 30, " Text Viewer")
        self.addControl(self.button3)

        self.setFocus(self.button2)

        self.button0.controlRight(self.button1)
        self.button0.controlLeft(self.button3)
        self.button0.controlUp(self.button3)
        self.button0.controlDown(self.button3)

        self.button1.controlRight(self.button2)
        self.button1.controlLeft(self.button0)
        self.button1.controlUp(self.button3)
        self.button1.controlDown(self.button3)

        self.button2.controlRight(self.button3)
        self.button2.controlLeft(self.button1)
        self.button2.controlUp(self.button3)
        self.button2.controlDown(self.button3)

        self.button3.controlRight(self.button0)
        self.button3.controlLeft(self.button2)
        self.button3.controlUp(self.button0)
        self.button3.controlDown(self.button0)

    def onAction(self, action):
        # non Display Button control
        if action == self.previous_menu:
            self.close()
        if action == self.back:
            self.close()

    def onControl(self, control):
        # Display Button control
        if control == self.button0:
            import notification
            notification.note()
            # message('Notice', 'Test button 0 is good')

        if control == self.button1:
            message('Notice', 'Test button 1 is good')

        if control == self.button2:
            self.close()

        if control == self.button3:
            # import textviewer
            # textviewer.text_view('log')
            textviewer.window()


def message(title, text):
    # Output display box
    dialog = xbmcgui.Dialog()
    dialog.ok(title, text)


def devicelog(path, text='', var=''):
    with open(path, 'a+') as log:
        log.write(text)
        log.write(var)
    log.close()


# on screen
def notification(header="", text="", sleep=5000):
    xbmc.executebuiltin("XBMC.Notification(%s,%s,%i)" % (header, text, sleep))


# Start of program
test_display = Display()
test_display.doModal()
del test_display



# EOF
