import xbmc
import xbmcgui
import xbmcaddon
import os

try:
    from urllib.request import urlopen, Request  # python 3.x
except ImportError:
    from urllib2 import urlopen, Request  # python 2.x

Addon = xbmcaddon.Addon()
addon_id = Addon.getAddonInfo('id')
settings = xbmcaddon.Addon(id=addon_id)

ACTION_LEFT = 1  # Left arrow key
ACTION_RIGHT = 2  # Right arrow key
ACTION_UP = 3  # Up arrow key
ACTION_DOWN = 4  # Down arrow key
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10  # ESC action
ACTION_SHOW_INFO = 11
ACTION_NEXT_ITEM = 14
ACTION_PREV_ITEM = 15
ACTION_BACKSPACE = 110
ACTION_CONTEXT_MENU = 117

ACTION_MOUSE_WHEEL_UP = 104  # Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105  # Mouse wheel down
ACTION_MOUSE_DRAG = 106  # Mouse drag
ACTION_MOUSE_MOVE = 107  # Mouse move

KEY_NAV_BACK = 92
KEY_HOME = 159
KEY_ESC = 61467


class PopupNote(xbmcgui.WindowXMLDialog):
    contents = ''
    note = 4001
    support = 4002
    social_media = 4003
    git_browser = 4004
    remind_later = 4005
    dismiss = 4006

    def __init__(self, xml_name, addons_path, skin_folder):
        super(PopupNote, self).__init__(self, xml_name, addons_path, skin_folder)
        self.page_up = 5
        self.page_down = 6
        self.previous_menu = 10
        self.back = 92
        self.buttonClicked = None

        # XML id's
        # self.main_window = 1100
        self.title_box_control = 20301
        self.content_box_control = 20302

    def onInit(self):
        image, self.contents = text_view(path='http://indigo.tvaddons.co/notifications/news.txt')
        # note_type = settings.getSetting("noteType")
        # image = settings.getSetting("noteImage")
        # self.contents = settings.getSetting("noteMessage")
        title_box = self.getControl(self.title_box_control)
        title_box.setText("[B][COLOR lime]Notes from Ele's Desk[/COLOR][/B]")
        content_box = self.getControl(self.content_box_control)
        content_box.setText(self.contents)

    def onAction(self, action):
        if action == self.previous_menu:
            self.close()
        elif action == self.back:
            # try:
            #     settings.setSetting("noteType", '')
            #     settings.setSetting("noteImage", '')
            #     settings.setSetting("noteMessage", '')
            # except:
            #     pass
            self.close()

    def onClick(self, control_id):
        if control_id == self.git_browser:
            self.close()
            xbmc.executebuiltin("RunAddon(plugin.git.browser)")

        elif control_id == self.remind_later:
            # try:
            #     settings.setSetting("noteType", '')
            #     settings.setSetting("noteImage", '')
            #     settings.setSetting("noteMessage", '')
            # except:
            #     pass
            self.close()

        elif control_id == self.dismiss:
            # try:
            #     settings.setSetting("noteType", note_type)
            #     settings.setSetting("noteImage", self.noteImage)
            #     settings.setSetting("noteMessage", self.noteMessage)
            # except:
            #     pass
            self.close()

        elif control_id == 4007:
            xbmcgui.Dialog().ok('', str(control_id))

    def onFocus(self, control_id):
        if control_id == self.note:
            title_box = self.getControl(self.title_box_control)
            title_box.setText("[B][COLOR lime]Notes from Ele's Desk[/COLOR][/B]")
            content_box = self.getControl(self.content_box_control)
            content_box.setText(self.contents)

        elif control_id == self.support:
            title_box = self.getControl(self.title_box_control)
            title_box.setText("[B][COLOR lime]Get Support From The TVA Community[/COLOR][/B]")
            contents2 = '\n\nPlease Visit: [COLOR blue]https://www.tvaddons/forums[/COLOR]'
            content_box = self.getControl(self.content_box_control)
            content_box.setText(contents2)

        elif control_id == self.social_media:
            title_box = self.getControl(self.title_box_control)
            title_box.setText("[B][COLOR lime]Follow Us On Social Media[/COLOR][/B]")
            contents3 = '\n\nTwitter: [COLOR blue]@tvaddonsco[/COLOR]' \
                        '\nFacebook: [COLOR blue]tvaddonsco[/COLOR]' \
                        '\nInstagram: [COLOR blue]tvaddonsco[/COLOR]' \
                        '\nYouTube: [COLOR blue]www.youtube.com/c/TVADDONSCO[/COLOR]'
            content_box = self.getControl(self.content_box_control)
            content_box.setText(contents3)

        elif control_id == self.git_browser:
            title_box = self.getControl(self.title_box_control)
            title_box.setText("[B][COLOR lime]Git Browser[/COLOR][/B]")
            contents4 = 'The Easiest Way to Install Unrestricted Kodi Addons'
            content_box = self.getControl(self.content_box_control)
            content_box.setText(contents4)

        elif control_id == self.remind_later:
            title_box = self.getControl(self.title_box_control)
            title_box.setText("[B][COLOR lime]Remind Me Later[/COLOR][/B]")
            contents5 = 'Show this notification the next time Kodi starts.\nUnless you opt-out in indigo'
            content_box = self.getControl(self.content_box_control)
            content_box.setText(contents5)

        elif control_id == self.dismiss:
            title_box = self.getControl(self.title_box_control)
            title_box.setText("[B][COLOR lime]Dismiss[/COLOR][/B]")
            contents6 = 'Show this notification on the next Kodi start only when a new notification comes out.' \
                        '\nUnless you opt-out in indigo'
            content_box = self.getControl(self.content_box_control)
            content_box.setText(contents6)

        elif control_id == 4007:
            xbmcgui.Dialog().ok('', str(control_id))


def art(f, fe=''):
    fe1 = '.png'
    fe2 = '.jpg'
    fe3 = '.gif'
    fe4 = '.wav'
    fe5 = '.txt'
    if fe1 in f:
        f = f.replace(fe1, '')
        fe = fe1
    elif fe2 in f:
        f = f.replace(fe2, '')
        fe = fe2
    elif fe3 in f:
        f = f.replace(fe3, '')
        fe = fe3
    elif fe4 in f:
        f = f.replace(fe4, '')
        fe = fe4
    elif fe5 in f:
        f = f.replace(fe5, '')
        fe = fe5
    # artPath = xbmc.translatePath(os.path.join(addon_path, 'noteart'))
    # return xbmc.translatePath(os.path.join(artPath, f + fe))
    return xbmc.translatePath(os.path.join(addon_path, 'noteart', f + fe))


def artp(f, fe='.png'):
    return art(f, fe)


def artj(f, fe='.jpg'):
    return art(f, fe)


def open_url(path):
    try:
        req = Request(path)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows U Windows NT 5.1 en-GB rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        contents = urlopen(req).read()
    except IOError:
        contents = 'The web site seems to be  having trouble. \nPlease try again later'
    return contents


def text_view(path='', contents=''):
    # path can be a url to an internet file. path to a local file. or the contents
    info_location2 = addon_path("test.txt")
    if path and not contents:
        if os.path.isfile(info_location2):
            try:
                with open(info_location2, 'rb') as temp_file:
                    contents = temp_file.read()
                    # kodi.log(info_location2)
            except IOError:
                contents = ''
        elif 'http' in path.lower():  # string.lower(path):
            contents = open_url(path)
        else:
            # Open and read a local file
            with open(path, 'rb') as temp_file:
                contents = temp_file.read()
    if not contents:
        return '', 'The file was empty'
    # Set contents for text display function
    if "|||" in contents:
        image = contents.split("|||")[0].strip()
        contents = contents.split("|||")[1].strip()
        return image, contents
    else:
        return '', contents


def addon_path(f, fe=''):
    path = settings.getAddonInfo('path')
    return xbmc.translatePath(os.path.join(path, f + fe))


def fetch_news():
    info_location = "http://indigo.tvaddons.co/notifications/news.txt"
    info_location2 = addon_path("test.txt")
    info_location3 = addon_path("url.txt")
    default_return = ['', '']
    if os.path.isfile(info_location2):
        try:
            with open(info_location2, 'rb') as temp_file:
                html = temp_file.read()
                # kodi.log(info_location2)
        except IOError:
            return default_return
    elif os.path.isfile(info_location3):
        try:
            # info_location3B = File_Open(info_location3).strip()
            with open(info_location3, 'rb') as temp_file:
                info_location3b = temp_file.read().strip()
            # if info_location3b > 0:
            # if info_location3b:
                html = open_url(info_location3b)
                # kodi.log(info_location3B)
            # else:
            #     return default_return
        except IOError:
            return default_return
    else:
        try:
            html = open_url(info_location)
            # kodi.log(info_location)
        except IOError:
            return default_return
    splitter = '|'
    if splitter in html:
        new_image = html.split(splitter)[0].strip()
        new_message = html.split(splitter)[1].strip()
        return new_image, new_message
    else:
        return '', html


def check_news(message_type, new_image, new_message, do_from_service=True):
    if (len(new_image) > 0) or (len(new_message) > 0):
        # debob(["notifications-on-startup", settings.getSetting("notifications-on-startup"), "do_from_service",
        #        do_from_service])
        if (settings.getSetting("notifications-on-startup") == 'false') or not do_from_service:
            # if new_image.lower() == "none":
            #     new_image = ""
            # if new_message.lower() == "none":
            #     new_message = ""
            old_note_image = settings.getSetting("noteImage")
            old_note_image = old_note_image.replace(artp('blank1'), '')
            old_note_message = settings.getSetting("noteMessage")
            # # if old_note_image.lower() == "none":
            # if old_note_image.lower() == '':
            #     old_note_image = ""
            # # if old_note_message.lower() == "none":
            # if old_note_message.lower() == '':
            #     old_note_message = ""
            if (not old_note_image == new_image or not old_note_message == new_message) or not do_from_service:
                settings.setSetting("noteType", message_type)
                settings.setSetting("noteImage", new_image)
                settings.setSetting("noteMessage", new_message)
                note()
                # TempWindow = MyWindow(noteType=message_type, noteMessage=new_message, noteImage=new_image)
                # TempWindow.doModal()
                # del TempWindow
            # elif do_from_service:
            elif (old_note_image == new_image or old_note_message == new_message) or do_from_service:
                return
            # else:
            #     TempWindow = MyWindow(noteType=TypeOfMessage, noteMessage=NewMessage, noteImage=NewImage)
            #     TempWindow.doModal()
            #     del TempWindow


def note():
    win = PopupNote('note-skin.xml', Addon.getAddonInfo('path'), 'notification')
    win.doModal()
    del win


def check_news2(message_type, override_service=False):
    if (settings.getSetting("notifications-on-startup") == 'false') or override_service:
        info_location = "http://indigo.tvaddons.co/notifications/news.txt"
        info_location2 = addon_path("test.txt")
        info_location3 = addon_path("url.txt")
        # default_return = ['', '']
        if os.path.isfile(info_location2):
            try:
                with open(info_location2, 'rb') as temp_file:
                    html = temp_file.read()
                    # kodi.log(info_location2)
            except IOError:
                html = ''
                # return ['', '']
        elif os.path.isfile(info_location3):
            try:
                # info_location3B = File_Open(info_location3).strip()
                with open(info_location3, 'rb') as temp_file:
                    info_location3b = temp_file.read().strip()
                # if info_location3b > 0:
                if info_location3b:
                    html = open_url(info_location3b)
                    # kodi.log(info_location3B)
                else:
                    html = ''
                #     return default_return
            except IOError:
                html = ''
                # return default_return
        else:
            try:
                html = open_url(info_location)
                # kodi.log(info_location)
            except IOError:
                html = ''
                # return default_return
        splitter = '|'
        if splitter in html:
            new_image = html.split(splitter)[0].strip()
            new_message = html.split(splitter)[1].strip()
            # return new_image, new_message
        else:
            new_image = ''
            new_message = html
            # return '', html

        if (len(new_image) > 0) or (len(new_message) > 0):
            # debob(["notifications-on-startup", settings.getSetting("notifications-on-startup"), "override_service ",
            #        override_service])
            # if new_image.lower() == "none":
            #     new_image = ""
            # if new_message.lower() == "none":
            #     new_message = ""
            old_note_image = settings.getSetting("noteImage")
            old_note_image = old_note_image.replace(artp('blank1'), '')
            old_note_message = settings.getSetting("noteMessage")
            # if old_note_image.lower() == "none":
            #     old_note_image = ""
            # if old_note_message.lower() == "none":
            #     old_note_message = ""
            if not old_note_image == new_image or not old_note_message == new_message:
                settings.setSetting("noteType", message_type)
                settings.setSetting("noteImage", new_image)
                settings.setSetting("noteMessage", new_message)
                win = PopupNote('note-skin.xml', Addon.getAddonInfo('path'), 'notification')
                win.doModal()
                del win
                # TempWindow = MyWindow(noteType=message_type, noteMessage=new_message, noteImage=new_image)
                # TempWindow.doModal()
                # del TempWindow
            # elif do_from_service:
            # elif (old_note_image == new_image or old_note_message == new_message) and not override_service:
            elif old_note_image == new_image or old_note_message == new_message:
                return
            # else:
            #     TempWindow = MyWindow(noteType=TypeOfMessage, noteMessage=NewMessage, noteImage=NewImage)
            #     TempWindow.doModal()
            #     del TempWindow
