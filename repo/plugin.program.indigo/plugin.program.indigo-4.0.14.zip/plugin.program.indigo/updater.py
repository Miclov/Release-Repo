import os
import re
import installer

import xbmc
import xbmcaddon
import xbmcgui

from libs import kodi

AddonTitle = kodi.addon.getAddonInfo('name')
addons_path = xbmc.translatePath(os.path.join('special://home', 'addons'))

updater_links = ('http://indigo.tvaddons.co/notifications/news.tx',
                 '/home/crzen/.kodi/addons/plugin.program.indigo/update_list.txt',
                 '/home/crzen/.kodi/addons/plugin.program.indigo/update_list2.txt',
                 '/home/crzen/.kodi/addons/plugin.program.indigo/update_list2.txt')


def updater():
    update_list = []
    kodi.log('STARTING ' + AddonTitle + ' UPDATER')
    for link in updater_links:
        contents = kodi.read_file(link, timeout=30)
        if re.search('(^# +enabled)$', contents, re.M | re.I):
            update_list = re.findall('(http.+?zip)', contents)
        if update_list:
            break
    # # Add user created lists to update_list
    # user_list = xbmcaddon.Addon().getSetting('user_list')
    # user_list = '/home/crzen/.kodi/addons/plugin.program.indigo/update_list.txt'
    # if user_list:
    #     contents = kodi.read_file(user_list)
    #     content_list = re.findall('(http.+?.zip)', contents)
    #     for source in content_list:
    #         update_list.append(source)
    if update_list:
        installed_addons = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.GetAddons", "id": "1"}')
        for source in update_list:
            name_id = os.path.basename(source).split('-')[0]
            version = os.path.basename(source).split('-')[1].replace('.zip', '')
            if name_id in installed_addons:
                contents = kodi.read_file(os.path.join(addons_path, name_id, 'addon.xml'))
                installed_version = re.search('(?s)<addon id=".+?version="([^"]*).+?python" version="([^"]*)', contents)
                if installed_version and version > installed_version.group(1):
                    installer.ADDONINSTALL(name_id, source, '', '', '', True, '', '')

                    xbmcgui.Dialog().ok('Was Updated', name_id, 'Old %s   PY %s   New %s'
                                        % (installed_version.group(1), installed_version.group(2), version), source)
                elif not installed_version:
                    xbmcgui.Dialog().ok('No Installed Version Match', name_id, installed_version, version)
                elif version <= installed_version.group(1):
                    xbmcgui.Dialog().ok('Not Greater', name_id, 'Old = ' + installed_version.group(1), 'New = ' + version)
            else:
                xbmcgui.Dialog().ok('Not Installed', name_id)
    xbmcgui.Dialog().ok('Done', 'Done')
