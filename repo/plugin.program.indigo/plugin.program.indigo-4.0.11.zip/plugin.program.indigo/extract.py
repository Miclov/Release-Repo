import zipfile
from libs import kodi
import sys
import traceback
import os


def all(_in, _out, dp=None):
    _in = os.path.realpath(_in)
    _out = os.path.realpath(_out)
    # kodi.okDialog(_in, _in.rsplit('/', 1)[1], _out, heading='Extract all')
    kodi.log('Starting Extract: in= ' + _in + '    _out= ' + _out
    try:
        zin = zipfile.ZipFile(_in, 'r')
        if not dp:
            zin.extractall(_out)
        else:
            n_files = float(len(zin.infolist()))
            count = 0
            for item in zin.infolist():
                count += 1
                update = count / n_files * 100
                dp.update(int(update))
                zin.extract(item, _out)
        return True
    except:
        traceback.print_exc(file=sys.stdout)
        try:
            import xbmc
            kodi.log('Exception try: in= ' + _in + '    _out= ' + _out
            xbmc.executebuiltin("Extract(%s, %s)" % (_in, _out))
            xbmc.sleep(1800)
            return True
        except Exception as e:
            traceback.print_exc(file=sys.stdout)
            kodi.okDialog(str(e), 'Please try again later', 'Attempting to continue...', "There was an error:")
            return False
