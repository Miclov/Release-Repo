from libs import textviewer

textviewer.window()

# EOF

